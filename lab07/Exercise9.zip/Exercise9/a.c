#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main(void) {
    pid_t pid;
    int fd_arr[2], i;
    char chr;
    pipe(fd_arr);
    pid = fork();
    if (pid == 0) {
        close(fd_arr[0]);
        for(i = 0; i < 10 ; i++) {
            chr = '0' + i;
            write(fd_arr[1], &chr, 1);
            sleep(1);
        }
        close(fd_arr[1]);
        exit(0);
    }
    close(fd_arr[1]);
    while (read(fd_arr[0], &chr, 1) > 0)
        write(STDOUT_FILENO, &chr, 1);
    write(STDOUT_FILENO, "\n", 1);
    close(fd_arr[0]);
    return 0;
}
